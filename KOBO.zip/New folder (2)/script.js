function showPlace(place) {
    let content = document.getElementById("content");

    if (place === "square") {
        content.innerHTML = `
            <h2>Makoanyane Square</h2>
            <p>A cultural and public gathering place in Maseru.</p>

            <video width="320" controls>
                <source src="videos/square-tour.mp4" type="video/mp4">
                Your browser does not support video.
            </video>
        `;

        speak("Welcome to Makoanyane Square, a cultural and public gathering place in Maseru.");
    }

    if (place === "mosque") {
        content.innerHTML = `
            <h2>Masjid E Al Huda</h2>
            <p>A peaceful religious landmark in Maseru.</p>

            <video width="320" controls>
                <source src="videos/masjid-tour.mp4" type="video/mp4">
                Your browser does not support video.
            </video>
        `;

        speak("Welcome to Masjid E Al Huda Mosque, a peaceful place of worship.");
    }
}

function speak(text) {
    let speech = new SpeechSynthesisUtterance(text);
    speechSynthesis.speak(speech);
}